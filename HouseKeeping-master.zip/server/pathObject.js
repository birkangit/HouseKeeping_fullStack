class PathObject {
  constructor() {
    this.diskId = "";
    this.pathRoot = "";
    this.usagePercentage = 0;
    this.maxPercentage = 0;
    this.files = [];
  }
}
module.exports = PathObject;
