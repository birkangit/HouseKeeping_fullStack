var config = [
  {
    path: "c:/test3",
    maxPercentage: 20,
  },
  {
    path: "c:/testEnv",
    maxPercentage: 90,
  },
  {
    path: "d:/test",
    maxPercentage: 20,
  },
  {
    path: "d:/test2",
    maxPercentage: 90,
  },
  {
    path: "d:/test3",
    maxPercentage: 20,
  },
  {
    path: "d:/test3",
    maxPercentage: 50,
  },
];

module.exports = config;
