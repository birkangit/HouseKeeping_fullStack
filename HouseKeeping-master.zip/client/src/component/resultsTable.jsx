function ResultsTable() {
  return (
    <div class="card">
      <div class="card-header">Last 10 processes</div>
      <ul class="list-group list-group-flush">
        <li class="list-group-item">
          15/09/2021 12:25:30 c:/test/file.txt has been deleted 15/09/2021
          12:25:30 c:/test/file.txt has been deleted
        </li>
        <li class="list-group-item">
          15/09/2021 12:25:30 c:/test/file.txt has been deleted
        </li>
        <li class="list-group-item">
          15/09/2021 12:25:30 c:/test/file.txt has been deleted
        </li>
      </ul>
    </div>
  );
}

export default ResultsTable;
